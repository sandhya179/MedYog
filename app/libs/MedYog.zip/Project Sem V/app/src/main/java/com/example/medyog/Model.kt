package com.example.medyog

data class Model (var url : String){




//    constructor() : this("dummyVId", "dummyTitle", "dummyUrl" )
////    override fun toString(): String {
////        return "Model(videoId='$videoId', title='$title', url='$url')"
////    }
//
//    fun getvideoId(): String {
//        return videoId
//    }
//
//    fun setvideoId(videoId: String) {
//        this.videoId = videoId
//    }
//
//    fun gettitle(): String {
//        return title
//    }
//
//    fun settitle(title: String) {
//        this.title = title
//    }
//
//    fun geturl(): String {
//        return url
//    }
//
//    fun seturl(url: String) {
//        this.url = url
//    }

}
