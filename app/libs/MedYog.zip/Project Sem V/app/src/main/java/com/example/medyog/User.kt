package com.example.medyog

data class User(val username : String? = null , val email : String? = null , val pass :String? = null,val confirmPass :String? = null, val bio : String? = null){

}
