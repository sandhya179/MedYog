package fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.medyog.EditProfile
import com.example.medyog.R
import com.example.medyog.databinding.ActivityEditProfileBinding
import com.example.medyog.databinding.FragmentProfileBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase


class ProfileFragment : Fragment() {
    private lateinit var binding: FragmentProfileBinding
    private val user = Firebase.auth.currentUser!!
    private lateinit var database: FirebaseDatabase



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(layoutInflater)
        database = FirebaseDatabase.getInstance()

        val username = binding.showUsername


        val edit = FragmentProfileBinding.inflate(layoutInflater)
        edit.editProfile.setOnClickListener{
            val intent = Intent(this@ProfileFragment.requireContext(),EditProfile::class.java)
            startActivity(intent)
        }

        return edit.root

        user?.let {
            database.reference.child("users").child(user.uid).child("username").get().addOnSuccessListener {
                username.setText(it.value.toString())
            }.addOnFailureListener{

            }
        }






    }


}