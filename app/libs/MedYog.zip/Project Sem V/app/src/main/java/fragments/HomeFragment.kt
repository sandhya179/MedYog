package fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.medyog.R
import com.example.medyog.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       val article = FragmentHomeBinding.inflate(layoutInflater)
        article.articleFirst.setOnClickListener{
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://medyogarticle.blogspot.com/2022/09/explore-about-spirituality.html")
            startActivity(openURL)
        }

        article.articleSecond.setOnClickListener{
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://medyogarticle.blogspot.com/2022/09/purpose-of-life.html")
            startActivity(openURL)
        }

        article.articleThird.setOnClickListener{
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://medyogarticle.blogspot.com/2022/09/the-path-to-true-happiness.html")
            startActivity(openURL)
        }

        article.articleFourth.setOnClickListener{
            val openURL = Intent(Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://medyogarticle.blogspot.com/2022/09/the-chakra-system.html")
            startActivity(openURL)
        }



        return article.root
    }


}