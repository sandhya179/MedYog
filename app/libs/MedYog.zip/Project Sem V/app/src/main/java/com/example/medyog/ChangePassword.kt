package com.example.medyog

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import com.example.medyog.databinding.ActivityChangePasswordBinding
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser


private lateinit var binding : ActivityChangePasswordBinding
private lateinit var auth : FirebaseAuth

class ChangePassword : AppCompatActivity() {

    val currentPass = binding.etCurrentPassword.text.toString()
    val newPass = binding.etNewPassword.text.toString()
    val confirmPass = binding.etConfirmPassword.text.toString()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val changeBtn = findViewById<Button>(R.id.btn_change_password)
        changeBtn.setOnClickListener {
            change()
        }
//        binding.btnChangePassword.setOnClickListener {
//            change()
//        }
    }

    private fun change() {

        if (currentPass.isNotEmpty() &&
            newPass.isNotEmpty() &&
            confirmPass.isNotEmpty()
        ) {
            if (newPass == confirmPass){
                val user : FirebaseUser? = auth.currentUser
                if(user != null && user.email != null){
                    val credential = EmailAuthProvider
                        .getCredential(user.email !!, currentPass)

// Prompt the user to re-provide their sign-in credentials
                    user.reauthenticate(credential)
                        .addOnCompleteListener {
                            if(it.isSuccessful){
                                Toast.makeText(this," Re-Authentication Success", Toast.LENGTH_SHORT).show()
                                user!!.updatePassword(newPass)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(this,"Password Changed Successfully", Toast.LENGTH_SHORT).show()
                                            auth.signOut()
                                            val intent = Intent (this, Login::class.java)
                                            startActivity(intent)
                                            finish()
                                        }
                                    }

                            }else{
                                Toast.makeText(this," Re-Authentication Failed", Toast.LENGTH_SHORT).show()
                            }
                        }

                }else{
                    val intent = Intent (this, Login::class.java)
                    startActivity(intent)
                    finish()
                }
            }else{
                Toast.makeText(this,"Password mismatching", Toast.LENGTH_SHORT).show()
            }

            } else {
            Toast.makeText(this, "Please enter all the fields", Toast.LENGTH_SHORT).show()
        }

    }
}
