package com.example.medyog

class Datasource {

    fun loadModel(): List<Model> {
        return listOf<Model>(
            Model ("0vj3__k4Mss"),
            Model ("QKDzmq3SWco"),
            Model ("Fyq3up4VMk8"),
            Model ("t9uyK4yxTb0"),
            Model ("7qVpqmtdTxA"),
            Model ("anawuUbr4p8"),
            Model ("qmaMm2P6y78"),
            Model ("D3-4Bt0pvG4"),
            Model ("77rbj8hBU7Q"),
            Model ("YmyfE-5sy9g"),
            Model ("6pjjPsR81fQ"),
            Model ("yLkEBjX71KY"),
            Model ("2ZN9CdO01jY"),
            Model ("U4mARY4GmRo"),
            Model ("sFP_ThS8-Kw")

        )
    }
}