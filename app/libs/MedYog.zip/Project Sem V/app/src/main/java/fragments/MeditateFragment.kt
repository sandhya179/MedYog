package fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.medyog.AdvancedMeditate
import com.example.medyog.BeginnerMeditate
import com.example.medyog.IntermediateMeditate
import com.example.medyog.R
import com.example.medyog.databinding.FragmentMeditateBinding


class MeditateFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = FragmentMeditateBinding.inflate(layoutInflater)

        view.MediateBeginnerBtn.setOnClickListener{
            val intent = Intent(this@MeditateFragment.requireContext(),BeginnerMeditate::class.java)
            startActivity(intent)
        }

        view.MeditateIntermediateBtn.setOnClickListener{
            val intent = Intent(this@MeditateFragment.requireContext(),IntermediateMeditate::class.java)
            startActivity(intent)
        }

        view.MediateAdvancedBtn.setOnClickListener{
            val intent = Intent(this@MeditateFragment.requireContext(),AdvancedMeditate::class.java)
            startActivity(intent)
        }
        return view.root


    }


}